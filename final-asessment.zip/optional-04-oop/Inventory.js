/**
 * TODO
 * Selesaikan kode pembuatan class Inventory dengan ketentuan:
 * - Memiliki properti `items` untuk menampung daftar item dalam bentuk array.
 * - Memiliki method `addItem` untuk menambahkan item ke properti `items`.
 * - Memiliki method `removeItem` untuk menghapus item berdasarkan `id`.
 * - Memiliki method `listItems` untuk mengembalikan string yang merupakan informasi detail barang (dipanggil dari fungs `item.displayDetails()`).
 */

class Inventory {}

// Jangan hapus kode di bawah ini!
export default Inventory;
class Inventory {
  constructor() {
      this.items = {};
    }
  
    // Menambah barang ke dalam inventaris
    addItem(id, name, quantity) {
      const item = new Item(id, name, quantity);
      this.items[id] = item;
    }
  
    // Menghapus barang dari inventaris
    removeItem(id) {
      delete this.items[id];
    }
  
    // Melihat daftar barang yang ada di dalam inventaris
    viewItems() {
      return Object.values(this.items);
    }
  
    // Memperbarui informasi barang yang ada di dalam inventaris
    updateItem(id, name, quantity) {
      const item = this.items[id];
      if (item) {
        item.update(name, quantity);
      }
    }
}


// Jangan hapus kode di bawah ini!
export default Inventory;

