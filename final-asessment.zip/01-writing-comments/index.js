// username: milamilo45

/*
Goal tahun ini:
1. Belajar JavaScript.
2. Menjadi Front-End atau Back-End Developer.
*/

const OrderManager = require('./orderManager');

const orderManager = new OrderManager();

// Menambahkan beberapa pesanan
const order1 = orderManager.addOrder('Alice', [
    { name: 'Pizza', price: 100000 },
    { name: 'Minuman', price: 20000 }
]);

const order2 = orderManager.addOrder('Bob', [
    { name: 'Burger', price: 50000 },
    { name: 'Kentang Goreng', price: 30000 }
]);

console.log('Daftar Pesanan:');
console.log(orderManager.getOrders());

console.log('Mengupdate status pesanan ID 1 menjadi Diproses:');
orderManager.updateOrderStatus(1, 'Diproses');
console.log(orderManager.getOrderById(1));

console.log('Mengupdate status pesanan ID 2 menjadi Selesai:');
orderManager.updateOrderStatus(2, 'Selesai');
console.log(orderManager.getOrderById(2));