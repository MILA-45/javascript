// index.test.js
import sum from './index.js';

describe('Fungsi sum', () => {
  
  test('Menjumlahkan dua bilangan positif', () => {
    expect(sum(2, 3)).toBe(5);
  });

  test('Menjumlahkan dua bilangan negatif', () => {
    expect(sum(-2, -3)).toBe(-5);
  });

  test('Menjumlahkan bilangan positif dan negatif', () => {
    expect(sum(5, -3)).toBe(2);
  });

  test('Menjumlahkan nol dengan bilangan positif', () => {
    expect(sum(0, 5)).toBe(5);
  });

  test('Menjumlahkan nol dengan bilangan negatif', () => {
    expect(sum(0, -5)).toBe(-5);
  });

  test('Menjumlahkan dua bilangan desimal', () => {
    expect(sum(2.5, 3.5)).toBe(6);
  });

  test('Menjumlahkan bilangan positif dengan nol', () => {
    expect(sum(3, 0)).toBe(3);
  });

  test('Menjumlahkan dua bilangan desimal negatif', () => {
    expect(sum(-1.5, -2.5)).toBe(-4);
  });

  test('Menjumlahkan dengan tipe data yang tidak valid', () => {
    expect(() => sum('a', 3)).toThrow();
    expect(() => sum(3, 'b')).toThrow();
    expect(() => sum(null, 3)).toThrow();
    expect(() => sum(3, undefined)).toThrow();
  });

});