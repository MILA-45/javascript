// index.test.js

import { test } from 'node:test';
import assert from 'node:assert';
import { sum } from './index.js'; // Pastikan untuk mengimpor fungsi sum dari index.js

test('sum function', () => {
    assert.strictEqual(sum(1, 2), 3); // Uji kasus 1: 1 + 2 = 3
    assert.strictEqual(sum(-1, 1), 0); // Uji kasus 2: -1 + 1 = 0
    assert.strictEqual(sum(-1, -1), -2); // Uji kasus 3: -1 + -1 = -2
    assert.strictEqual(sum(0, 0), 0); // Uji kasus 4: 0 + 0 = 0
    assert.strictEqual(sum(100, 200), 300); // Uji kasus 5: 100 + 200 = 300
});